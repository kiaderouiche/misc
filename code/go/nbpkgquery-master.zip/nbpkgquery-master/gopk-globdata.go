package main


// GlobalData contains data describing pkgsrc.
type GlobalData struct {
	Pkgsrcdir           string              // Relative to the current working directory.
	MasterSiteUrls      map[string]string   // "https://github.com/" => "MASTER_SITE_GITHUB"
	MasterSiteVars      map[string]bool     // "MASTER_SITE_GITHUB" => true
	PkgOptions          map[string]string   // "x11" => "Provides X11 support"
	Tools               map[string]bool     // Known tool names, e.g. "sed" and "gm4".
	Vartools            map[string]string   // Maps tool names to their respective variable, e.g. "sed" => "SED", "gzip" => "GZIP_CMD".
	PredefinedTools     map[string]bool     // Tools that a package does not need to add to USE_TOOLS explicitly because they are used by the pkgsrc infrastructure, too.
	VarnameToToolname   map[string]string   // Maps the tool variable names to the tool name they use, e.g. "GZIP_CMD" => "gzip" and "SED" => "sed".
	SystemBuildDefs     map[string]bool     // The set of user-defined variables that are added to BUILD_DEFS within the bsd.pkg.mk file.
	toolvarsVarRequired map[string]bool     // Tool variable names that may not be converted to their "direct" form, that is: ${CP} may not be written as cp.
	toolsVarRequired    map[string]bool     // Tools that need to be written in variable form, e.g. "echo"; see Vartools.
	suggestedUpdates    []SuggestedUpdate   //
	suggestedWipUpdates []SuggestedUpdate   //
	LastChange          map[string]*Change  //
	UserDefinedVars     map[string]*MkLine  // varname => line
	Deprecated          map[string]string   //
	vartypes            map[string]*Vartype // varcanon => type
}