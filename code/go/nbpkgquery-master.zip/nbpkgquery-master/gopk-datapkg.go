package main

type Package struct {
	Pkgpath       string // "math/pkgdir"
	Pkgpathcall   string
	Filesdir      string // FILE from the package Makefile, Makefile.common,
	Pkgcategory   string
	Pkgname       *PkgName
	Pkgversion    string
	PkgMasterSite string
	Maintainer    string
	Pkghomepage   string
	Comment       string
	Pkglicense    string
	DistinfoFile  string
	DescrFile     string
	PatchDir      string
	bl3mk         string
	MessageFile   string
	TodoFile      string
}

type PkgName struct {
	_pkgdistname string
	_pkgnanme    string
}

type PkgUrl struct {
	UrlofficWeb      string // http://cdn.netbsd.org/pub/pkgsrc/current/pkgsrc/README-all.html
	UrlRepositoryFtp string //
}
