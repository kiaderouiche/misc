package main

// def applyargs(func, **kwds):
//     return func(**kwds)


// def main():
//     import argparse

//     parser = argparse.ArgumentParser(
//         description='nbpkgquery - NetBSD Search in pkgsrc Framework')
//     subparsers = parser.add_subparsers()

//     # local
//     parser_init = subparsers.add_parser(
//         'local', help='initialize nbpkgquery directory')
//     parser_init.add_argument(
//         'descr', default='.', nargs='?',
//         help='root directory to initialize (default: "%(default)s")')
//     parser_init.set_defaults(func=init)

//     # web
//     parser_web = subparsers.add_parser(
//         'web', help='start stand-alone webserver')
//     parser_web.add_argument(
//         '-p', '--port', type=int, default=8000,
//         help='port to listen (default: %(default)s)')
//     parser_web.add_argument(
//         '-R', '--root',
//         help='root directory (where `.neorg/` exists)',
//         )
//     parser_serve.add_argument(
//         '-b', '--browser', action='store_true',
//         help='open web browser',
//         )
//     parser_serve.add_argument(
//         '--debug', action='store_true', default=None,
//         help='set DEBUG=True to run in debug mode')
//     parser_serve.set_defaults(func=serve)

//     args = parser.parse_args()
//     return applyargs(**vars(args))


// if __name__ == '__main__':
//     main()
