package main

import "fmt"
import "io"
import "os"
import "path/filepath"


const appVersion = "0.0.1"

// Init structure
type Pkgsearch struct{}


func main() {
	cli.logOut, cli.logErr, cli.debugOut = os.Stdout, os.Stderr, os.Stdout
	os.Exit(new(Pkgsearch).Init(os.Args...))
}
