#nbpkgquery

**nbpkgquery v1.-1pre01** tool independante operating system for search package information based pkgsrc framework.

nbpkgquery provides three features:

1. local search

2. remote local search

3. web search

## Requirements

- Go development environment: >= **go1.10**

## Installation

Install from source code

    go get -u -v github.com/kiaderouiche/nbpkgquery

The executable will be produced under `$GOPATH/bin` in your file system; for global use purpose, we recommand you to add this path into your `PATH` environment variable.

##Usage:


   $ nbquery root -all
   
   $ nbquery distcln package
   
   $ nbquery local -D package

   $ nbquery remote -C package

   $ nbquery web -M maintainer

   $ nbquery task (request pkgsrc/TODO file)
   
   $ nbquery inspect package.tbz package.tgz

## License

This project is under the MIT License, See the [LICENSE](LICENSE) file for the full license text.
